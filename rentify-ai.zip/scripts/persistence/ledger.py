"""Conexiones explícitas; los llamadores son responsables de cerrarlas."""

import sqlite3
from pathlib import Path


def connect(database: Path, timeout: float = 5.0) -> sqlite3.Connection:
    if timeout < 0:
        raise ValueError("timeout debe ser no negativo")
    conn = sqlite3.connect(str(database), timeout=timeout, isolation_level=None)
    try:
        conn.execute("PRAGMA foreign_keys = ON")
        if conn.execute("PRAGMA foreign_keys").fetchone()[0] != 1:
            raise RuntimeError("No se pudo activar foreign_keys")
        return conn
    except BaseException:
        conn.close()
        raise
